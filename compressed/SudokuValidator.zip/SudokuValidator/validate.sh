java -jar target/SudokuValidator-1.0-SNAPSHOT.jar $1
